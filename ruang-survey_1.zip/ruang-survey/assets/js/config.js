// ISI DUA NILAI INI dari Supabase -> Project Settings -> API
// (pakai "Project URL" dan kunci "anon public". JANGAN pakai service_role!)
window.RS_CONFIG = {
  SUPABASE_URL: "https://GANTI-DENGAN-PROJECT-ID.supabase.co",
  SUPABASE_ANON_KEY: "GANTI-DENGAN-ANON-PUBLIC-KEY"
};
